# a23d
A square 3D


---

This repo contains the static site for A² 3D Lab (GitHub Pages). Open index.html to preview.